package sample;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.web.bind.annotation.*;
import sample.DAO.SurveyDAO;
import sample.DAO.UserDAO;
import sample.entity.Survey;
import sample.entity.User;

import java.util.List;


@RestController
public class Controller {
    @RequestMapping(value = "/api/user",method = RequestMethod.POST)
    public String index(@RequestParam("username") String name) {
        UserDAO udao = new UserDAO();
        User temp = new User();
        temp.setUsername(name);
        udao.add(temp);
        return temp.toString();
    }

    @RequestMapping(value="api/survey",method = RequestMethod.POST)
    public String index(@RequestParam("user_id")int id, @RequestParam("title")String title, @RequestParam("question")String question){

        UserDAO udao = new UserDAO();
        SurveyDAO surdao = new SurveyDAO();

        User temp = udao.read(id);

        Survey buff = new Survey();
        buff.setUser_id(temp.getUser_id());
        buff.setQuestion(question);
        buff.setSurvey_title(title);

        surdao.add(buff);

        return buff.toString();
    }

    @RequestMapping(value="api/survey/user/{ID}",method=RequestMethod.GET)
    public String index(@PathVariable("ID")int id){
        SurveyDAO surdao = new SurveyDAO();
        String buff="";


        String hql = "SELECT * FROM Survey WHERE user_id="+id;
        HibernateFactory hibernateFactory = new HibernateFactory();
        Session session = hibernateFactory.getSessionFactory().openSession();
        Transaction transaction = session.beginTransaction();
        try {
            Query query = session.createQuery(hql);

            List result=query.list();
            for(int i=0;i<result.size();i++){
                buff+=result.get(i);
            }

                session.getTransaction().commit();
        } catch (Exception ex) {
            transaction.rollback();
            ex.printStackTrace();
            throw new RuntimeException(ex);
        } finally {
            session.close();
        }


//        int i=0;
//        String buff="";
//        while(surdao.read(i)!=null){
//            Survey temp = surdao.read(i);
//            if(temp.getUser_id()==id){
//                buff+=temp.toString()+"\r\n";
//            }
//            i++;
//        }
//        return buff;
        return buff;
    }



}




